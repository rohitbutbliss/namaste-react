#This script will run npm commands and parcel commands to build your application
npm install && npx parcel build index.html